export const brands = [
    {
      "brandName": "Trek",
      "description": "High-quality bikes for all terrains",
      "slug": "trek"
    },
    {
      "brandName": "Giant",
      "description": "Specializing in road and mountain bikes",
      "slug": "giant"
    },
    {
      "brandName": "Specialized",
      "description": "Innovative designs for cycling enthusiasts",
      "slug": "specialized"
    },
    {
      "brandName": "Cannondale",
      "description": "Known for its performance-oriented bicycles",
      "slug": "cannondale"
    },
    {
      "brandName": "Scott",
      "description": "Offers a wide range of bicycles for various purposes",
      "slug": "scott"
    }
  ]
  