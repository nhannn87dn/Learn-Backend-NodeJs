export const customers = [
    {
      "firstName": "Nguyễn",
      "lastName": "Thị Lan",
      "email": "lannt@gmail.com",
      "phone": "0381234567",
      "address": "12 Nguyễn Văn Cừ",
      "yard": "An Hải Bắc",
      "district": "Sơn Trà",
      "province": "Đà Nẵng",
      "password": "Lan@1234",
      "isEmailVerified": false,
      "sort": 1,
      "isActive": true
    },
    {
      "firstName": "Trần",
      "lastName": "Văn Minh",
      "email": "minhtv@gmail.com",
      "phone": "0387654321",
      "address": "45 Lê Duẩn",
      "yard": "Hải Châu I",
      "district": "Hải Châu",
      "province": "Đà Nẵng",
      "password": "Minh@1234",
      "isEmailVerified": true,
      "sort": 2,
      "isActive": true
    }
  ]
  